
var motions = {};

/*	
**	The function adds values ​​to the table 
**  and fills up the object
*/
$('#addNewMove').on('click', addMove);
function addMove(){

	var form = $('#moveForm')[0];

	var cntRowTable = $('#tableMove tr').length;
	var direction = form.direction.value;
	var duration = form.duration.value*1;
	var cntRowMotions = cntRowTable-1;

	motions[cntRowMotions] = {
		cntRowTable: cntRowTable,
		direction: direction,
		duration: duration
	};

	$('#tableMove')
		.append(
			'<tr><td>'+cntRowTable+
			'</td><td>'+direction+
			'</td><td>'+duration+
			'</td><td>edit, delete </td></tr>'
			);
}


/*	
**	The function determines the direction 
**	and calls the corresponding function
*/	
$("#play").on('click', animation); 
function animation(){
	var canvas = $( "#canvas" );
	var square = $( "#square" );

	var position = {
		position: 'absolute',
		top: $(square)[0]['offsetTop'],
		left: $(square)[0]['offsetLeft']
	};
  	square.css(position);

  	for(move in motions) {
  		switch(motions[move]['direction']) {
  			case 'left': 
  				if(border($('#square')))
  				leftSquare(square, motions[move]['duration']);
  				break;

  			case 'right': 
  				if(border($('#square')))
  				rightSquare(square, motions[move]['duration']);
  				break;

  			case 'top': 
				if(border($('#square')))
  				topSquare(square, motions[move]['duration']);
  				break;

  			case 'bottom': 
  				if(border($('#square')))
  				bottomSquare(square, motions[move]['duration']);
  				break;
  		}

  	}

}


/*
**	Wrapper functions 
**	for moving a square
*/
function leftSquare(obj, duration){
	console.log('x');
	obj.animate({
		left: "-=10"
	}, duration);
};
function rightSquare(obj, duration){
	obj.animate({
		left: "+=10"
	}, duration);
};
function bottomSquare(obj, duration){
	obj.animate({
		top: "+=10"
	}, duration);
};
function topSquare(obj, duration){
	obj.animate({
		top: "-=10"
	}, duration);
};
function border(obj){
	var result = true;

	var topObj = $(obj)[0]['offsetTop'];
	var leftObj = $(obj)[0]['offsetLeft'];

	var widthObj = $(obj)[0]['offsetWidth'];
	var heightObj = $(obj)[0]['offsetHeight'];

	var parent = $(obj).parent();

	var parentLeft = parent[0]['offsetLeft'] + widthObj;
	var parentRight = parent[0]['offsetWidth'] - parentLeft;
	var parentTop = parent[0]['offsetTop'] + heightObj;
	var parentBottom = parent[0]['offsetHeight'] + parentTop - heightObj*2;

	if(leftObj <= parentLeft) 
		result = false;
	if(leftObj >= parentRight)
		result = false;
	if(topObj <= parentTop)
		result = false;
	if(topObj >= parentBottom)
		result = false;

	console.log(parentLeft+" : "+
				parentRight+" : "+
				parentTop+" : "+
				parentBottom+" : "+
				topObj+" : "+
				result);
	return result;
}
